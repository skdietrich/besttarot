// Tarot Reading State Management
// Using React Context for state management

import React, { createContext, useContext, useReducer } from 'react';
import type { ReactNode } from 'react';
import type { TarotCard } from '@/data/tarotCards';
import type { SpreadType } from '@/data/spreads';
import type { DeckType } from '@/data/decks';

// Types
export interface DrawnCard {
  card: TarotCard;
  reversed: boolean;
  position: number;
  positionName: string;
}

export interface ReadingSession {
  id: string;
  timestamp: number;
  question: string;
  deck: DeckType;
  spread: SpreadType;
  cards: DrawnCard[];
  notes: string;
}

export type ReadingPhase = 
  | 'setup'      // Initial setup - select deck, spread, enter question
  | 'shuffling'  // One-minute shuffling animation
  | 'drawing'    // Drawing cards
  | 'revealing'  // Revealing cards one by one
  | 'complete';  // Reading complete - can export

interface ReadingState {
  // Current session
  currentSession: ReadingSession | null;
  
  // Configuration
  selectedDeck: DeckType;
  selectedSpread: SpreadType;
  question: string;
  
  // Phase
  phase: ReadingPhase;
  
  // Shuffling state
  shuffleProgress: number;
  shuffleStartTime: number | null;
  
  // Drawing state
  drawnCards: DrawnCard[];
  currentRevealIndex: number;
  
  // History
  sessionHistory: ReadingSession[];
  
  // Settings
  allowReversed: boolean;
  animationSpeed: 'slow' | 'normal' | 'fast';
}

type ReadingAction =
  | { type: 'SET_DECK'; payload: DeckType }
  | { type: 'SET_SPREAD'; payload: SpreadType }
  | { type: 'SET_QUESTION'; payload: string }
  | { type: 'START_SHUFFLING' }
  | { type: 'UPDATE_SHUFFLE_PROGRESS'; payload: number }
  | { type: 'FINISH_SHUFFLING' }
  | { type: 'START_DRAWING' }
  | { type: 'ADD_DRAWN_CARD'; payload: DrawnCard }
  | { type: 'REVEAL_NEXT_CARD' }
  | { type: 'REVEAL_ALL_CARDS' }
  | { type: 'COMPLETE_READING' }
  | { type: 'RESET_READING' }
  | { type: 'SAVE_SESSION' }
  | { type: 'LOAD_SESSION'; payload: ReadingSession }
  | { type: 'SET_ALLOW_REVERSED'; payload: boolean }
  | { type: 'SET_ANIMATION_SPEED'; payload: 'slow' | 'normal' | 'fast' }
  | { type: 'CLEAR_HISTORY' };

// Initial state
const initialState: ReadingState = {
  currentSession: null,
  selectedDeck: 'rider-waite',
  selectedSpread: 'three',
  question: '',
  phase: 'setup',
  shuffleProgress: 0,
  shuffleStartTime: null,
  drawnCards: [],
  currentRevealIndex: -1,
  sessionHistory: [],
  allowReversed: true,
  animationSpeed: 'normal'
};

// Reducer
function readingReducer(state: ReadingState, action: ReadingAction): ReadingState {
  switch (action.type) {
    case 'SET_DECK':
      return { ...state, selectedDeck: action.payload };
    
    case 'SET_SPREAD':
      return { ...state, selectedSpread: action.payload };
    
    case 'SET_QUESTION':
      return { ...state, question: action.payload };
    
    case 'START_SHUFFLING':
      return {
        ...state,
        phase: 'shuffling',
        shuffleProgress: 0,
        shuffleStartTime: Date.now(),
        drawnCards: [],
        currentRevealIndex: -1
      };
    
    case 'UPDATE_SHUFFLE_PROGRESS':
      return { ...state, shuffleProgress: action.payload };
    
    case 'FINISH_SHUFFLING':
      return { ...state, phase: 'drawing', shuffleProgress: 100 };
    
    case 'START_DRAWING':
      return { ...state, phase: 'revealing', drawnCards: [], currentRevealIndex: 0 };
    
    case 'ADD_DRAWN_CARD':
      return {
        ...state,
        drawnCards: [...state.drawnCards, action.payload]
      };
    
    case 'REVEAL_NEXT_CARD':
      return {
        ...state,
        currentRevealIndex: Math.min(
          state.currentRevealIndex + 1,
          state.drawnCards.length - 1
        )
      };
    
    case 'REVEAL_ALL_CARDS':
      return {
        ...state,
        currentRevealIndex: state.drawnCards.length - 1
      };
    
    case 'COMPLETE_READING':
      const completedSession: ReadingSession = {
        id: generateSessionId(),
        timestamp: Date.now(),
        question: state.question,
        deck: state.selectedDeck,
        spread: state.selectedSpread,
        cards: state.drawnCards,
        notes: ''
      };
      return {
        ...state,
        phase: 'complete',
        currentSession: completedSession,
        sessionHistory: [completedSession, ...state.sessionHistory].slice(0, 50)
      };
    
    case 'RESET_READING':
      return {
        ...initialState,
        sessionHistory: state.sessionHistory,
        selectedDeck: state.selectedDeck,
        selectedSpread: state.selectedSpread,
        allowReversed: state.allowReversed,
        animationSpeed: state.animationSpeed
      };
    
    case 'SAVE_SESSION':
      if (!state.currentSession) return state;
      return {
        ...state,
        sessionHistory: [state.currentSession, ...state.sessionHistory].slice(0, 50)
      };
    
    case 'LOAD_SESSION':
      const session = action.payload;
      return {
        ...state,
        currentSession: session,
        selectedDeck: session.deck,
        selectedSpread: session.spread,
        question: session.question,
        drawnCards: session.cards,
        phase: 'complete'
      };
    
    case 'SET_ALLOW_REVERSED':
      return { ...state, allowReversed: action.payload };
    
    case 'SET_ANIMATION_SPEED':
      return { ...state, animationSpeed: action.payload };
    
    case 'CLEAR_HISTORY':
      return { ...state, sessionHistory: [] };
    
    default:
      return state;
  }
}

// Generate unique session ID
function generateSessionId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 9)}`;
}

// Context
interface ReadingContextType {
  state: ReadingState;
  dispatch: React.Dispatch<ReadingAction>;
}

const ReadingContext = createContext<ReadingContextType | null>(null);

// Provider
interface ReadingProviderProps {
  children: ReactNode;
}

export function ReadingProvider({ children }: ReadingProviderProps) {
  const [state, dispatch] = useReducer(readingReducer, initialState);
  
  return (
    <ReadingContext.Provider value={{ state, dispatch }}>
      {children}
    </ReadingContext.Provider>
  );
}

// Hook
export function useReading() {
  const context = useContext(ReadingContext);
  if (!context) {
    throw new Error('useReading must be used within a ReadingProvider');
  }
  return context;
}

// Selectors
export function useSelectedDeck(): DeckType {
  const { state } = useReading();
  return state.selectedDeck;
}

export function useSelectedSpread(): SpreadType {
  const { state } = useReading();
  return state.selectedSpread;
}

export function useQuestion(): string {
  const { state } = useReading();
  return state.question;
}

export function usePhase(): ReadingPhase {
  const { state } = useReading();
  return state.phase;
}

export function useDrawnCards(): DrawnCard[] {
  const { state } = useReading();
  return state.drawnCards;
}

export function useShuffleProgress(): number {
  const { state } = useReading();
  return state.shuffleProgress;
}

export function useCurrentRevealIndex(): number {
  const { state } = useReading();
  return state.currentRevealIndex;
}

export function useSessionHistory(): ReadingSession[] {
  const { state } = useReading();
  return state.sessionHistory;
}

export function useCurrentSession(): ReadingSession | null {
  const { state } = useReading();
  return state.currentSession;
}

export function useAllowReversed(): boolean {
  const { state } = useReading();
  return state.allowReversed;
}

export function useAnimationSpeed(): 'slow' | 'normal' | 'fast' {
  const { state } = useReading();
  return state.animationSpeed;
}

// Export types
export type { ReadingState, ReadingAction };

import React from 'react';
import { Sparkles, Stars, Moon, Sun } from 'lucide-react';

interface HeroSectionProps {
  onStartReading: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onStartReading }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        {/* Gradient orbs */}
        <div 
          className="absolute top-1/4 left-1/4 w-[600px] h-[600px] rounded-full opacity-30"
          style={{
            background: 'radial-gradient(circle, hsl(45 80% 55%), transparent)',
            filter: 'blur(100px)',
            animation: 'float 8s ease-in-out infinite'
          }}
        />
        <div 
          className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, hsl(270 60% 50%), transparent)',
            filter: 'blur(80px)',
            animation: 'float 10s ease-in-out infinite reverse'
          }}
        />
        
        {/* Stars */}
        <div className="absolute inset-0">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 rounded-full bg-amber-200/40 twinkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${1 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
        
        {/* Decorative symbols */}
        <div className="absolute top-20 left-20 opacity-20">
          <Moon className="w-16 h-16 text-amber-400" />
        </div>
        <div className="absolute bottom-20 right-20 opacity-20">
          <Sun className="w-16 h-16 text-amber-400" />
        </div>
        <div className="absolute top-1/3 right-1/4 opacity-10">
          <Stars className="w-24 h-24 text-purple-400" />
        </div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full 
          bg-amber-500/10 border border-amber-500/30 mb-8">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-sm text-amber-300 font-heading tracking-wider">
            MONTE CARLO RANDOMIZATION
          </span>
        </div>
        
        {/* Title */}
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading text-gradient-gold mb-6
          leading-tight">
          Mystic Tarot
          <br />
          <span className="text-4xl md:text-6xl lg:text-7xl">Oracle</span>
        </h1>
        
        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-amber-200/70 font-mystic mb-4 max-w-2xl mx-auto">
          Discover the wisdom of the cards through truly random divination
        </p>
        
        {/* Description */}
        <p className="text-base text-amber-200/50 mb-12 max-w-xl mx-auto leading-relaxed">
          Experience authentic tarot readings with our sophisticated Monte Carlo randomization 
          engine. Choose from multiple decks and spreads, from simple 3-card draws to the 
          complete Celtic Cross.
        </p>
        
        {/* Features */}
        <div className="flex flex-wrap justify-center gap-6 mb-12 text-sm text-amber-200/60">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-amber-400" />
            <span>5 Unique Decks</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-purple-400" />
            <span>4 Spread Types</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Anti-Bias Algorithm</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-rose-400" />
            <span>LLM Export</span>
          </div>
        </div>
        
        {/* CTA Button */}
        <button
          onClick={onStartReading}
          className="mystic-button text-lg px-12 py-5"
        >
          <span className="flex items-center gap-3">
            <Sparkles className="w-5 h-5" />
            Begin Your Reading
            <Sparkles className="w-5 h-5" />
          </span>
        </button>
        
        {/* Decorative line */}
        <div className="mt-16 flex items-center justify-center gap-4">
          <div className="w-24 h-px bg-gradient-to-r from-transparent to-amber-500/50" />
          <div className="w-2 h-2 rounded-full bg-amber-400/60" />
          <div className="w-24 h-px bg-gradient-to-l from-transparent to-amber-500/50" />
        </div>
        
        {/* Trust indicators */}
        <p className="mt-8 text-xs text-amber-200/40">
          78 Cards • 4 Spreads • True Randomness • Commercial Quality
        </p>
      </div>
    </section>
  );
};

export default HeroSection;

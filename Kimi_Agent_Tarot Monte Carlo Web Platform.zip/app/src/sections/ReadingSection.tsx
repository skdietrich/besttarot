import React, { useState, useEffect } from 'react';
import { Sparkles, Eye, RotateCcw } from 'lucide-react';
import type { DrawnCard } from '@/store/readingStore';
import type { SpreadType } from '@/data/spreads';
import type { DeckType } from '@/data/decks';
import { getSpreadById } from '@/data/spreads';
import { TarotCard } from '@/components/TarotCard';

interface ReadingSectionProps {
  cards: DrawnCard[];
  spread: SpreadType;
  deck: DeckType;
  question: string;
  currentRevealIndex: number;
  onRevealNext: () => void;
  onRevealAll: () => void;
  onReset: () => void;
  onExport: () => void;
}

export const ReadingSection: React.FC<ReadingSectionProps> = ({
  cards,
  spread,
  deck,
  question,
  currentRevealIndex,
  onRevealNext,
  onRevealAll,
  onReset,
  onExport
}) => {
  const [selectedCardIndex, setSelectedCardIndex] = useState<number | null>(null);
  const [showAllRevealed, setShowAllRevealed] = useState(false);
  
  const spreadConfig = getSpreadById(spread);
  const allRevealed = currentRevealIndex >= cards.length - 1;
  
  useEffect(() => {
    if (allRevealed && !showAllRevealed) {
      setShowAllRevealed(true);
    }
  }, [allRevealed, showAllRevealed]);
  
  const selectedCard = selectedCardIndex !== null ? cards[selectedCardIndex] : null;
  
  const getLayoutClass = () => {
    switch (spread) {
      case 'three':
        return 'grid-cols-3 gap-6';
      case 'five':
        return 'grid-cols-3 gap-4';
      case 'seven':
        return 'grid-cols-4 gap-4';
      case 'celtic-cross':
        return 'grid-cols-4 gap-3';
      default:
        return 'grid-cols-3 gap-4';
    }
  };
  
  const getPositionStyle = (index: number) => {
    if (spread === 'five') {
      // Cross layout for 5 cards
      const positions = [
        'col-start-2 row-start-1', // Center
        'col-start-2 row-start-1 translate-x-8', // Cross (overlapping)
        'col-start-2 row-start-2', // Bottom
        'col-start-1 row-start-1', // Left
        'col-start-3 row-start-1', // Right
      ];
      return positions[index] || '';
    }
    return '';
  };
  
  return (
    <section className="min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-heading text-gradient-gold mb-3">
            Your Reading
          </h2>
          <p className="text-lg text-amber-200/60 font-mystic max-w-2xl mx-auto">
            {question}
          </p>
          <p className="text-sm text-amber-400/50 mt-2">
            {spreadConfig?.name} • {cards.length} cards
          </p>
        </div>
        
        {/* Progress indicator */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-2">
            {cards.map((_, index) => (
              <div
                key={index}
                className={`
                  w-3 h-3 rounded-full transition-all duration-300
                  ${index <= currentRevealIndex 
                    ? 'bg-amber-400 scale-110' 
                    : 'bg-amber-400/20'}
                `}
              />
            ))}
          </div>
        </div>
        
        {/* Controls */}
        <div className="flex justify-center gap-4 mb-8">
          {!allRevealed ? (
            <>
              <button
                onClick={onRevealNext}
                className="mystic-button flex items-center gap-2"
              >
                <Eye className="w-4 h-4" />
                Reveal Next Card
              </button>
              <button
                onClick={onRevealAll}
                className="mystic-button-secondary flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Reveal All
              </button>
            </>
          ) : (
            <>
              <button
                onClick={onExport}
                className="mystic-button flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Export Reading
              </button>
              <button
                onClick={onReset}
                className="mystic-button-secondary flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                New Reading
              </button>
            </>
          )}
        </div>
        
        {/* Cards grid */}
        <div className={`
          grid ${getLayoutClass()} gap-4 md:gap-6 mb-8
          max-w-5xl mx-auto
        `}>
          {cards.map((drawnCard, index) => {
            const isRevealed = index <= currentRevealIndex;
            const position = spreadConfig?.positions[index];
            
            return (
              <div
                key={index}
                className={`
                  relative flex flex-col items-center
                  ${getPositionStyle(index)}
                  transition-all duration-500
                  ${isRevealed ? 'opacity-100' : 'opacity-70'}
                `}
              >
                {/* Position label */}
                <div className="mb-2 text-center">
                  <span className="text-xs text-amber-400/60 font-heading">
                    {position?.name}
                  </span>
                </div>
                
                {/* Card */}
                <div
                  onClick={() => isRevealed && setSelectedCardIndex(index)}
                  className={`
                    relative cursor-pointer transition-all duration-300
                    ${isRevealed ? 'hover:scale-105' : ''}
                    ${selectedCardIndex === index ? 'ring-2 ring-amber-400 rounded-xl' : ''}
                  `}
                >
                  {isRevealed ? (
                    <TarotCard
                      card={drawnCard.card}
                      reversed={drawnCard.reversed}
                      deck={deck}
                      size="lg"
                      animate={true}
                      delay={index * 100}
                    />
                  ) : (
                    <div className="w-44 h-64 rounded-xl card-back flex items-center justify-center">
                      <span className="text-4xl opacity-50">✦</span>
                    </div>
                  )}
                  
                  {/* Position number badge */}
                  <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full 
                    bg-gradient-to-br from-amber-400 to-amber-600
                    flex items-center justify-center text-amber-900 font-bold text-sm
                    shadow-lg shadow-amber-500/30">
                    {index + 1}
                  </div>
                </div>
                
                {/* Card name (when revealed) */}
                {isRevealed && (
                  <div className="mt-3 text-center">
                    <p className="text-sm font-heading text-amber-200">
                      {drawnCard.card.name}
                    </p>
                    {drawnCard.reversed && (
                      <span className="text-xs text-red-400/80">Reversed</span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Card detail modal */}
        {selectedCard && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedCardIndex(null)}
          >
            <div 
              className="mystic-card max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-start gap-6">
                {/* Card image */}
                <div className="flex-shrink-0">
                  <TarotCard
                    card={selectedCard.card}
                    reversed={selectedCard.reversed}
                    deck={deck}
                    size="xl"
                  />
                </div>
                
                {/* Card details */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-heading text-gradient-gold">
                        {selectedCard.card.name}
                      </h3>
                      <p className="text-sm text-amber-400/60">
                        Position: {spreadConfig?.positions[selectedCardIndex!]?.name}
                      </p>
                    </div>
                    
                    {selectedCard.reversed && (
                      <span className="px-3 py-1 rounded-full bg-red-500/20 
                        text-red-400 text-sm font-heading">
                        Reversed
                      </span>
                    )}
                  </div>
                  
                  {/* Keywords */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedCard.card.keywords.map(keyword => (
                      <span key={keyword}
                        className="px-2 py-1 rounded-full bg-amber-500/10 
                          text-amber-300 text-xs">
                        {keyword}
                      </span>
                    ))}
                  </div>
                  
                  {/* Meaning */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-heading text-amber-400 mb-2">
                        {selectedCard.reversed ? 'Reversed Meaning' : 'Upright Meaning'}
                      </h4>
                      <p className="text-sm text-amber-200/70 leading-relaxed">
                        {selectedCard.reversed 
                          ? selectedCard.card.reversedMeaning 
                          : selectedCard.card.uprightMeaning}
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-heading text-amber-400 mb-2">
                        Position Meaning
                      </h4>
                      <p className="text-sm text-amber-200/70 leading-relaxed">
                        {spreadConfig?.positions[selectedCardIndex!]?.meaning}
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-heading text-amber-400 mb-2">
                        Advice
                      </h4>
                      <p className="text-sm text-amber-200/70 leading-relaxed">
                        {selectedCard.card.advice}
                      </p>
                    </div>
                    
                    {/* Symbolism */}
                    <div>
                      <h4 className="text-sm font-heading text-amber-400 mb-2">
                        Symbolism
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedCard.card.symbolism.map(symbol => (
                          <span key={symbol}
                            className="text-xs text-amber-200/50">
                            {symbol}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Close button */}
              <button
                onClick={() => setSelectedCardIndex(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full 
                  bg-amber-500/20 text-amber-400 hover:bg-amber-500/30
                  flex items-center justify-center transition-colors"
              >
                ×
              </button>
            </div>
          </div>
        )}
        
        {/* Reading complete message */}
        {allRevealed && (
          <div className="text-center mt-12">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full
              bg-amber-500/10 border border-amber-500/30">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span className="text-amber-300 font-heading">
                Reading Complete
              </span>
              <Sparkles className="w-5 h-5 text-amber-400" />
            </div>
            
            <p className="mt-4 text-sm text-amber-200/50 max-w-lg mx-auto">
              Take time to reflect on the cards and their meanings. 
              Consider how they relate to your question and what guidance they offer.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default ReadingSection;

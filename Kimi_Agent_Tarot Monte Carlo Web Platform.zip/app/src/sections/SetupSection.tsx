import React, { useState } from 'react';
import { BookOpen, LayoutGrid, HelpCircle, Sparkles, ChevronRight, Info } from 'lucide-react';
import type { DeckType } from '@/data/decks';
import type { SpreadType } from '@/data/spreads';
import { allDecks } from '@/data/decks';
import { allSpreads } from '@/data/spreads';

interface SetupSectionProps {
  selectedDeck: DeckType;
  selectedSpread: SpreadType;
  question: string;
  onDeckChange: (deck: DeckType) => void;
  onSpreadChange: (spread: SpreadType) => void;
  onQuestionChange: (question: string) => void;
  onStartShuffle: () => void;
}

export const SetupSection: React.FC<SetupSectionProps> = ({
  selectedDeck,
  selectedSpread,
  question,
  onDeckChange,
  onSpreadChange,
  onQuestionChange,
  onStartShuffle
}) => {
  const [activeTab, setActiveTab] = useState<'deck' | 'spread' | 'question'>('deck');
  const [hoveredDeck, setHoveredDeck] = useState<DeckType | null>(null);
  
  const selectedDeckConfig = allDecks.find(d => d.id === selectedDeck);
  const selectedSpreadConfig = allSpreads.find(s => s.id === selectedSpread);
  
  const isReady = question.trim().length > 0;
  
  return (
    <section className="min-h-screen py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-heading text-gradient-gold mb-4">
            Configure Your Reading
          </h2>
          <p className="text-lg text-amber-200/60 font-mystic">
            Select your deck, choose a spread, and set your intention
          </p>
        </div>
        
        {/* Progress tabs */}
        <div className="flex justify-center mb-12">
          <div className="flex items-center gap-2 bg-secondary/30 rounded-full p-2">
            {[
              { id: 'deck', icon: BookOpen, label: 'Deck' },
              { id: 'spread', icon: LayoutGrid, label: 'Spread' },
              { id: 'question', icon: HelpCircle, label: 'Question' }
            ].map((tab, index) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`
                  flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-300
                  ${activeTab === tab.id 
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50' 
                    : 'text-amber-400/60 hover:text-amber-300'}
                `}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-heading text-sm">{tab.label}</span>
                {index < 2 && <ChevronRight className="w-4 h-4 ml-2 opacity-50" />}
              </button>
            ))}
          </div>
        </div>
        
        {/* Content area */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main selection area */}
          <div className="lg:col-span-2">
            {activeTab === 'deck' && (
              <div className="space-y-4">
                <h3 className="text-xl font-heading text-amber-300 mb-6">
                  Choose Your Deck
                </h3>
                
                <div className="grid sm:grid-cols-2 gap-4">
                  {allDecks.map(deck => (
                    <button
                      key={deck.id}
                      onClick={() => onDeckChange(deck.id)}
                      onMouseEnter={() => setHoveredDeck(deck.id)}
                      onMouseLeave={() => setHoveredDeck(null)}
                      className={`
                        relative p-6 rounded-xl text-left transition-all duration-300
                        ${selectedDeck === deck.id 
                          ? 'bg-amber-500/20 border-2 border-amber-500/60' 
                          : 'bg-secondary/30 border-2 border-transparent hover:border-amber-500/30'}
                      `}
                    >
                      {/* Deck color indicator */}
                      <div 
                        className="absolute top-4 right-4 w-4 h-4 rounded-full"
                        style={{ background: deck.colorScheme.primary }}
                      />
                      
                      <h4 className="text-lg font-heading text-amber-200 mb-2">
                        {deck.name}
                      </h4>
                      
                      <p className="text-sm text-amber-200/50 mb-3 line-clamp-2">
                        {deck.description}
                      </p>
                      
                      <div className="flex items-center gap-2 text-xs text-amber-400/60">
                        <span className="px-2 py-1 rounded bg-amber-500/10">
                          {deck.style}
                        </span>
                        <span className="px-2 py-1 rounded bg-amber-500/10">
                          {deck.difficulty}
                        </span>
                      </div>
                      
                      {/* Hover info */}
                      {hoveredDeck === deck.id && (
                        <div className="absolute inset-0 rounded-xl bg-black/80 p-4 
                          flex flex-col justify-center items-center text-center
                          animate-in fade-in duration-200">
                          <p className="text-xs text-amber-200/70 mb-2">
                            Best for:
                          </p>
                          <div className="flex flex-wrap justify-center gap-1">
                            {deck.bestFor.map(item => (
                              <span key={item} 
                                className="text-xs px-2 py-1 rounded-full bg-amber-500/20 text-amber-300">
                                {item}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {activeTab === 'spread' && (
              <div className="space-y-4">
                <h3 className="text-xl font-heading text-amber-300 mb-6">
                  Choose Your Spread
                </h3>
                
                <div className="space-y-4">
                  {allSpreads.map(spread => (
                    <button
                      key={spread.id}
                      onClick={() => onSpreadChange(spread.id)}
                      className={`
                        w-full p-6 rounded-xl text-left transition-all duration-300
                        ${selectedSpread === spread.id 
                          ? 'bg-amber-500/20 border-2 border-amber-500/60' 
                          : 'bg-secondary/30 border-2 border-transparent hover:border-amber-500/30'}
                      `}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="text-lg font-heading text-amber-200 mb-2">
                            {spread.name}
                          </h4>
                          <p className="text-sm text-amber-200/50 mb-3">
                            {spread.description}
                          </p>
                        </div>
                        
                        <div className="flex flex-col items-end gap-2">
                          <span className="text-2xl font-heading text-amber-400">
                            {spread.cardCount}
                          </span>
                          <span className="text-xs text-amber-400/60">cards</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4 mt-4">
                        <span className="text-xs text-amber-400/60">
                          Difficulty: <span className="text-amber-300">{spread.difficulty}</span>
                        </span>
                        <span className="text-xs text-amber-400/60">
                          Time: <span className="text-amber-300">{spread.estimatedTime}</span>
                        </span>
                      </div>
                      
                      {/* Position preview */}
                      <div className="flex items-center gap-2 mt-4">
                        {spread.positions.slice(0, 5).map((pos, i) => (
                          <div key={pos.id} 
                            className="w-8 h-10 rounded bg-amber-500/10 border border-amber-500/30
                            flex items-center justify-center text-xs text-amber-400">
                            {i + 1}
                          </div>
                        ))}
                        {spread.positions.length > 5 && (
                          <span className="text-xs text-amber-400/60">
                            +{spread.positions.length - 5} more
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {activeTab === 'question' && (
              <div className="space-y-6">
                <h3 className="text-xl font-heading text-amber-300 mb-6">
                  Set Your Intention
                </h3>
                
                <div className="mystic-card p-6">
                  <label className="block text-sm text-amber-200/70 mb-3">
                    What would you like guidance on?
                  </label>
                  
                  <textarea
                    value={question}
                    onChange={(e) => onQuestionChange(e.target.value)}
                    placeholder="Enter your question or the area of life you'd like insight into..."
                    className="mystic-input min-h-[150px] resize-none"
                  />
                  
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-xs text-amber-200/40">
                      {question.length}/500 characters
                    </p>
                    
                    {!isReady && (
                      <p className="text-xs text-amber-400/60 flex items-center gap-1">
                        <Info className="w-3 h-3" />
                        Please enter a question to continue
                      </p>
                    )}
                  </div>
                </div>
                
                {/* Question suggestions */}
                <div className="space-y-3">
                  <p className="text-sm text-amber-200/50">Or choose a suggestion:</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {[
                      "What do I need to know about my current situation?",
                      "What guidance do I need for my career path?",
                      "What should I focus on in my relationships?",
                      "What is blocking my personal growth?",
                      "What opportunities are coming my way?",
                      "What do I need to release to move forward?"
                    ].map(suggestion => (
                      <button
                        key={suggestion}
                        onClick={() => onQuestionChange(suggestion)}
                        className="text-left px-4 py-2 rounded-lg bg-secondary/30 
                          text-sm text-amber-200/60 hover:bg-amber-500/10 
                          hover:text-amber-300 transition-all"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Summary sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-4">
              <div className="mystic-card p-6">
                <h4 className="text-lg font-heading text-amber-300 mb-4">
                  Reading Summary
                </h4>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-xs text-amber-200/50 mb-1">Selected Deck</p>
                    <p className="text-sm text-amber-200 font-medium">
                      {selectedDeckConfig?.name}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-amber-200/50 mb-1">Selected Spread</p>
                    <p className="text-sm text-amber-200 font-medium">
                      {selectedSpreadConfig?.name}
                    </p>
                    <p className="text-xs text-amber-200/40 mt-1">
                      {selectedSpreadConfig?.cardCount} cards • {selectedSpreadConfig?.estimatedTime}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-amber-200/50 mb-1">Your Question</p>
                    <p className="text-sm text-amber-200/80 line-clamp-3">
                      {question || <span className="italic text-amber-200/40">Not set yet</span>}
                    </p>
                  </div>
                </div>
                
                {/* Start button */}
                <button
                  onClick={onStartShuffle}
                  disabled={!isReady}
                  className={`
                    w-full mt-6 py-4 rounded-lg font-heading text-sm tracking-wider
                    flex items-center justify-center gap-2 transition-all duration-300
                    ${isReady 
                      ? 'mystic-button' 
                      : 'bg-secondary/50 text-amber-400/40 cursor-not-allowed'}
                  `}
                >
                  <Sparkles className="w-4 h-4" />
                  {isReady ? 'Begin Reading' : 'Enter Question First'}
                </button>
                
                {isReady && (
                  <p className="text-xs text-center text-amber-400/60 mt-3">
                    The cards will shuffle for 1 minute using Monte Carlo randomization
                  </p>
                )}
              </div>
              
              {/* Info card */}
              <div className="mystic-card p-4">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-amber-400 mt-0.5" />
                  <div>
                    <p className="text-sm text-amber-200/70 mb-1">
                      About Our Randomization
                    </p>
                    <p className="text-xs text-amber-200/50">
                      We use Monte Carlo simulation with 10,000 iterations, 
                      entropy pooling, and anti-bias algorithms to ensure 
                      truly random card selection.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SetupSection;

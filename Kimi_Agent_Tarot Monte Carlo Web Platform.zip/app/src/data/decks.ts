// Tarot Deck Configurations
// Multiple deck styles for different reading experiences

export type DeckType = 'rider-waite' | 'marseille' | 'thoth' | 'mystic' | 'celestial';

export interface DeckConfig {
  id: DeckType;
  name: string;
  description: string;
  creator: string;
  year: number;
  style: 'illustrated' | 'symbolic' | 'abstract' | 'photographic';
  cardBackDesign: string;
  colorScheme: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
  };
  characteristics: string[];
  bestFor: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  hasReversed: boolean;
  imageStyle: string;
}

// Rider-Waite-Smith Deck
export const riderWaiteDeck: DeckConfig = {
  id: 'rider-waite',
  name: 'Rider-Waite-Smith',
  description: 'The most popular and influential tarot deck in the world. Rich with symbolic imagery that makes interpretation accessible for beginners while offering depth for advanced readers.',
  creator: 'Arthur Edward Waite & Pamela Colman Smith',
  year: 1909,
  style: 'illustrated',
  cardBackDesign: 'Rose and lily crosshatch pattern with stars',
  colorScheme: {
    primary: '#1E3A5F',    // Deep blue
    secondary: '#C9A227',  // Gold
    accent: '#8B0000',     // Deep red
    background: '#F5F5DC'  // Cream
  },
  characteristics: [
    'Detailed scenic illustrations on all 78 cards',
    'Rich symbolic imagery',
    'Clear narrative scenes',
    'Christian and Hermetic symbolism',
    'Emotional expressiveness'
  ],
  bestFor: ['Beginners', 'Visual learners', 'Narrative readings', 'General questions'],
  difficulty: 'beginner',
  hasReversed: true,
  imageStyle: 'Classic tarot illustrations with detailed symbolic scenes, rich colors, art nouveau influences'
};

// Tarot de Marseille
export const marseilleDeck: DeckConfig = {
  id: 'marseille',
  name: 'Tarot de Marseille',
  description: 'The traditional European tarot with stylized, non-scenic pip cards. Requires intuitive interpretation and offers a more mystical, open-ended reading experience.',
  creator: 'Traditional (Various)',
  year: 1650,
  style: 'symbolic',
  cardBackDesign: 'Geometric floral pattern in blue and white',
  colorScheme: {
    primary: '#1B4B7A',    // Marseille blue
    secondary: '#D4AF37',  // Antique gold
    accent: '#8B4513',     // Saddle brown
    background: '#FFF8DC'  // Cornsilk
  },
  characteristics: [
    'Non-scenic pip cards (2-10)',
    'Stylized, flat illustrations',
    'Primary color palette',
    'Geometric arrangements',
    'Requires intuitive interpretation'
  ],
  bestFor: ['Advanced readers', 'Intuitive readings', 'Meditation', 'Traditional practice'],
  difficulty: 'advanced',
  hasReversed: false,
  imageStyle: 'Traditional European woodcut style, flat perspective, primary colors, geometric patterns'
};

// Thoth Deck
export const thothDeck: DeckConfig = {
  id: 'thoth',
  name: 'Thoth Tarot',
  description: 'Aleister Crowley\'s esoteric masterpiece rich with Qabalah, astrology, and Egyptian symbolism. A deep, complex deck for serious spiritual seekers.',
  creator: 'Aleister Crowley & Lady Frieda Harris',
  year: 1944,
  style: 'symbolic',
  cardBackDesign: 'Rosy cross with geometric patterns',
  colorScheme: {
    primary: '#4B0082',    // Indigo
    secondary: '#FFD700',  // Gold
    accent: '#DC143C',     // Crimson
    background: '#1a1a2e'  // Deep purple-black
  },
  characteristics: [
    'Dense esoteric symbolism',
    'Qabalistic and astrological correspondences',
    'Egyptian mythology references',
    'Renamed cards (e.g., "Adjustment" for Justice)',
    'Complex color symbolism'
  ],
  bestFor: ['Esoteric study', 'Advanced practitioners', 'Astrological readings', 'Spiritual growth'],
  difficulty: 'advanced',
  hasReversed: true,
  imageStyle: 'Esoteric symbolic art with Egyptian motifs, astrological symbols, rich jewel tones, complex geometry'
};

// Mystic Deck
export const mysticDeck: DeckConfig = {
  id: 'mystic',
  name: 'Mystic Oracle',
  description: 'A contemporary mystical deck blending traditional symbolism with modern spiritual aesthetics. Ethereal and dreamlike for intuitive readings.',
  creator: 'Contemporary Artists',
  year: 2020,
  style: 'abstract',
  cardBackDesign: 'Celestial mandala with moon phases',
  colorScheme: {
    primary: '#6B4EE6',    // Mystic purple
    secondary: '#00D4AA',  // Teal
    accent: '#FF6B9D',     // Rose
    background: '#0D1117'  // Dark cosmic
  },
  characteristics: [
    'Dreamlike ethereal imagery',
    'Contemporary mystical aesthetic',
    'Enhanced intuitive connection',
    'Soft, flowing compositions',
    'Celestial and nature themes'
  ],
  bestFor: ['Intuitive readings', 'Meditation', 'Dream work', 'Modern practitioners'],
  difficulty: 'intermediate',
  hasReversed: true,
  imageStyle: 'Ethereal mystical art with soft glows, cosmic elements, flowing forms, dreamlike atmosphere'
};

// Celestial Deck
export const celestialDeck: DeckConfig = {
  id: 'celestial',
  name: 'Celestial Wisdom',
  description: 'An astronomical tarot deck connecting ancient wisdom with cosmic consciousness. Stars, planets, and constellations guide your readings.',
  creator: 'Astronomical Artists',
  year: 2021,
  style: 'photographic',
  cardBackDesign: 'Star field with zodiac wheel',
  colorScheme: {
    primary: '#1a1b3a',    // Deep space
    secondary: '#F4E4C1',  // Starlight
    accent: '#9B59B6',     // Nebula purple
    background: '#0a0a0f'  // Void black
  },
  characteristics: [
    'Astronomical imagery',
    'Constellation patterns',
    'Planetary associations',
    'Cosmic consciousness themes',
    'Scientific and mystical blend'
  ],
  bestFor: ['Astrology enthusiasts', 'Cosmic guidance', 'Spiritual astronomy', 'Modern mystics'],
  difficulty: 'intermediate',
  hasReversed: true,
  imageStyle: 'Astronomical photography style with nebulae, stars, planets, cosmic phenomena, deep space colors'
};

// All decks collection
export const allDecks: DeckConfig[] = [
  riderWaiteDeck,
  marseilleDeck,
  thothDeck,
  mysticDeck,
  celestialDeck
];

// Get deck by ID
export const getDeckById = (id: DeckType): DeckConfig | undefined => {
  return allDecks.find(deck => deck.id === id);
};

// Get default deck
export const getDefaultDeck = (): DeckConfig => riderWaiteDeck;

// Get deck card back style
export const getCardBackStyle = (deckId: DeckType): React.CSSProperties => {
  const deck = getDeckById(deckId);
  if (!deck) return {};
  
  const baseStyle: React.CSSProperties = {
    background: `linear-gradient(135deg, ${deck.colorScheme.primary}, ${deck.colorScheme.secondary})`,
    border: `2px solid ${deck.colorScheme.accent}`,
  };
  
  switch (deckId) {
    case 'rider-waite':
      return {
        ...baseStyle,
        backgroundImage: `repeating-linear-gradient(
          45deg,
          transparent,
          transparent 10px,
          ${deck.colorScheme.accent}20 10px,
          ${deck.colorScheme.accent}20 20px
        )`
      };
    case 'marseille':
      return {
        ...baseStyle,
        backgroundImage: `radial-gradient(circle at 30% 30%, ${deck.colorScheme.secondary}40, transparent 50%)`
      };
    case 'thoth':
      return {
        ...baseStyle,
        backgroundImage: `conic-gradient(from 0deg, ${deck.colorScheme.primary}, ${deck.colorScheme.secondary}, ${deck.colorScheme.accent}, ${deck.colorScheme.primary})`
      };
    case 'mystic':
      return {
        ...baseStyle,
        backgroundImage: `radial-gradient(ellipse at center, ${deck.colorScheme.accent}30, transparent 70%)`
      };
    case 'celestial':
      return {
        ...baseStyle,
        backgroundImage: `radial-gradient(circle at 20% 20%, ${deck.colorScheme.secondary}30, transparent 30%),
                          radial-gradient(circle at 80% 80%, ${deck.colorScheme.accent}20, transparent 30%)`
      };
    default:
      return baseStyle;
  }
};

// Get deck-specific card styling
export const getCardStyle = (deckId: DeckType, isReversed: boolean = false): React.CSSProperties => {
  const deck = getDeckById(deckId);
  if (!deck) return {};
  
  const baseStyle: React.CSSProperties = {
    border: `2px solid ${deck.colorScheme.accent}`,
    boxShadow: `0 4px 20px ${deck.colorScheme.primary}40`,
  };
  
  if (isReversed) {
    baseStyle.transform = 'rotate(180deg)';
  }
  
  return baseStyle;
};

// Get deck border gradient
export const getDeckBorderGradient = (deckId: DeckType): string => {
  const deck = getDeckById(deckId);
  if (!deck) return 'linear-gradient(135deg, #666, #999)';
  
  return `linear-gradient(135deg, ${deck.colorScheme.primary}, ${deck.colorScheme.secondary}, ${deck.colorScheme.accent})`;
};

// Export default
export default allDecks;

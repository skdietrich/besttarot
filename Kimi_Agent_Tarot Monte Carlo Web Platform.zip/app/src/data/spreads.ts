// Tarot Spread Configurations
// Definitions for 3, 5, 7, and 10-card Celtic Cross spreads

export type SpreadType = 'three' | 'five' | 'seven' | 'celtic-cross';

export interface SpreadPosition {
  id: number;
  name: string;
  description: string;
  meaning: string;
  element?: string;
  timing?: string;
  aspect: 'past' | 'present' | 'future' | 'challenge' | 'advice' | 'outcome' | 'self' | 'external' | 'hidden' | 'spiritual';
}

export interface SpreadConfig {
  id: SpreadType;
  name: string;
  description: string;
  cardCount: number;
  positions: SpreadPosition[];
  layout: 'row' | 'cross' | 'horseshoe' | 'pyramid';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  bestFor: string[];
  estimatedTime: string;
}

// Three Card Spread - Past, Present, Future
export const threeCardSpread: SpreadConfig = {
  id: 'three',
  name: 'Past, Present, Future',
  description: 'A classic three-card spread that reveals the trajectory of your situation through time. Perfect for quick insights and understanding how past influences shape your present and future.',
  cardCount: 3,
  layout: 'row',
  difficulty: 'beginner',
  bestFor: ['Quick questions', 'Daily guidance', 'Understanding timing', 'Simple decisions'],
  estimatedTime: '2-3 minutes',
  positions: [
    {
      id: 1,
      name: 'The Past',
      description: 'What has led to your current situation',
      meaning: 'This card represents past events, influences, and experiences that have shaped your current circumstances. It reveals the foundation upon which your present situation rests.',
      element: 'Earth',
      timing: 'Past - Recent to distant',
      aspect: 'past'
    },
    {
      id: 2,
      name: 'The Present',
      description: 'Your current situation and energy',
      meaning: 'This card reveals your present circumstances, the energies currently surrounding you, and the immediate factors at play in your life right now.',
      element: 'Air',
      timing: 'Present - Now',
      aspect: 'present'
    },
    {
      id: 3,
      name: 'The Future',
      description: 'Where your current path is leading',
      meaning: 'This card indicates the likely outcome or direction your situation is heading based on current energies and trajectories. Remember, the future is not fixed.',
      element: 'Fire',
      timing: 'Future - Near to distant',
      aspect: 'future'
    }
  ]
};

// Five Card Spread - Cross
export const fiveCardSpread: SpreadConfig = {
  id: 'five',
  name: 'The Five-Cross',
  description: 'A powerful cross-shaped spread that explores your situation from multiple angles. Reveals the core issue, supporting and opposing forces, and guidance for moving forward.',
  cardCount: 5,
  layout: 'cross',
  difficulty: 'intermediate',
  bestFor: ['Complex situations', 'Decision making', 'Understanding influences', 'Finding direction'],
  estimatedTime: '4-5 minutes',
  positions: [
    {
      id: 1,
      name: 'The Center',
      description: 'The heart of your question',
      meaning: 'This central card represents the core of your situation - the primary energy, issue, or theme around which everything else revolves.',
      element: 'Spirit',
      timing: 'Present',
      aspect: 'present'
    },
    {
      id: 2,
      name: 'The Challenge',
      description: 'What crosses or blocks you',
      meaning: 'This card crosses the center, representing obstacles, challenges, or opposing forces that you must navigate or overcome.',
      element: 'Earth',
      timing: 'Present - Immediate',
      aspect: 'challenge'
    },
    {
      id: 3,
      name: 'The Foundation',
      description: 'What supports and grounds you',
      meaning: 'This card beneath the center represents your foundation - past influences, subconscious factors, and the root cause of your situation.',
      element: 'Earth',
      timing: 'Past - Deep root',
      aspect: 'past'
    },
    {
      id: 4,
      name: 'The Crown',
      description: 'Your highest potential or goal',
      meaning: 'This card above the center represents your aspirations, conscious goals, and the highest potential outcome of your situation.',
      element: 'Fire',
      timing: 'Future - Aspirational',
      aspect: 'future'
    },
    {
      id: 5,
      name: 'The Outcome',
      description: 'Where this leads',
      meaning: 'This final card reveals the likely outcome if current energies continue, offering guidance on how your situation may resolve.',
      element: 'Water',
      timing: 'Future - Probable',
      aspect: 'outcome'
    }
  ]
};

// Seven Card Spread - Horseshoe
export const sevenCardSpread: SpreadConfig = {
  id: 'seven',
  name: 'The Horseshoe',
  description: 'A comprehensive seven-card spread arranged in a horseshoe shape. Provides deep insight into your situation through past influences, hidden factors, and future possibilities.',
  cardCount: 7,
  layout: 'horseshoe',
  difficulty: 'intermediate',
  bestFor: ['In-depth readings', 'Complex relationships', 'Career decisions', 'Life transitions'],
  estimatedTime: '6-8 minutes',
  positions: [
    {
      id: 1,
      name: 'The Past',
      description: 'Past influences affecting you',
      meaning: 'This card reveals past events, experiences, and influences that have created your current situation. It shows where you have been.',
      element: 'Earth',
      timing: 'Past',
      aspect: 'past'
    },
    {
      id: 2,
      name: 'The Present',
      description: 'Your current situation',
      meaning: 'This card represents your present circumstances, the current energy surrounding you, and where you stand right now.',
      element: 'Air',
      timing: 'Present',
      aspect: 'present'
    },
    {
      id: 3,
      name: 'Hidden Influences',
      description: 'Forces working behind the scenes',
      meaning: 'This card reveals unseen factors, subconscious influences, or hidden elements that are affecting your situation without your awareness.',
      element: 'Water',
      timing: 'Ongoing - Hidden',
      aspect: 'hidden'
    },
    {
      id: 4,
      name: 'Obstacles',
      description: 'Challenges you face',
      meaning: 'This card at the center of the horseshoe represents the primary obstacle, challenge, or blockage you must overcome.',
      element: 'Earth',
      timing: 'Present - Challenge',
      aspect: 'challenge'
    },
    {
      id: 5,
      name: 'External Influences',
      description: 'People and circumstances around you',
      meaning: 'This card reveals external factors, other people, and environmental circumstances that are influencing your situation.',
      element: 'Air',
      timing: 'Present - External',
      aspect: 'external'
    },
    {
      id: 6,
      name: 'Advice',
      description: 'Guidance for your path',
      meaning: 'This card offers specific guidance, advice, or a recommended approach for navigating your situation successfully.',
      element: 'Fire',
      timing: 'Action needed',
      aspect: 'advice'
    },
    {
      id: 7,
      name: 'The Outcome',
      description: 'The likely result',
      meaning: 'This final card reveals the most probable outcome if current energies and advice are followed.',
      element: 'Water',
      timing: 'Future',
      aspect: 'outcome'
    }
  ]
};

// Celtic Cross Spread - 10 Cards
export const celticCrossSpread: SpreadConfig = {
  id: 'celtic-cross',
  name: 'The Celtic Cross',
  description: 'The most comprehensive and revered tarot spread. Ten cards arranged in a cross and staff formation reveal every aspect of your situation - from subconscious influences to future outcomes.',
  cardCount: 10,
  layout: 'cross',
  difficulty: 'advanced',
  bestFor: ['Major life questions', 'Deep spiritual insight', 'Complex situations', 'Year-ahead readings'],
  estimatedTime: '10-15 minutes',
  positions: [
    {
      id: 1,
      name: 'The Present',
      description: 'Your current situation',
      meaning: 'This card represents your present position, the core energy of your question, and the primary factor in your current circumstances.',
      element: 'Air',
      timing: 'Now',
      aspect: 'present'
    },
    {
      id: 2,
      name: 'The Challenge',
      description: 'What crosses you',
      meaning: 'This card crosses the present position, representing the immediate challenge, obstacle, or opposing force you face.',
      element: 'Earth',
      timing: 'Immediate',
      aspect: 'challenge'
    },
    {
      id: 3,
      name: 'The Foundation',
      description: 'The root of the matter',
      meaning: 'This card beneath represents the foundation of the situation - past influences, subconscious roots, and what has already been established.',
      element: 'Earth',
      timing: 'Past - Root',
      aspect: 'past'
    },
    {
      id: 4,
      name: 'The Past',
      description: 'Recent influences',
      meaning: 'This card behind represents recent past events and influences that are still affecting your current situation.',
      element: 'Water',
      timing: 'Recent Past',
      aspect: 'past'
    },
    {
      id: 5,
      name: 'The Crown',
      description: 'Your aspirations and goals',
      meaning: 'This card above represents your conscious goals, aspirations, and what you are working toward achieving.',
      element: 'Fire',
      timing: 'Future - Goal',
      aspect: 'future'
    },
    {
      id: 6,
      name: 'The Future',
      description: 'What is coming',
      meaning: 'This card before you represents the near future - events and influences that are approaching or about to manifest.',
      element: 'Air',
      timing: 'Near Future',
      aspect: 'future'
    },
    {
      id: 7,
      name: 'The Self',
      description: 'Your attitude and approach',
      meaning: 'This card represents you in the situation - your thoughts, feelings, attitudes, and how you are approaching the matter.',
      element: 'Fire',
      timing: 'Present - Internal',
      aspect: 'self'
    },
    {
      id: 8,
      name: 'External Influences',
      description: 'People and environment around you',
      meaning: 'This card reveals external influences, other people, and environmental factors that are affecting your situation.',
      element: 'Air',
      timing: 'Present - External',
      aspect: 'external'
    },
    {
      id: 9,
      name: 'Hopes & Fears',
      description: 'Your inner hopes and anxieties',
      meaning: 'This card reveals your hopes, fears, and expectations about the situation - what you desire and what you worry about.',
      element: 'Water',
      timing: 'Present - Emotional',
      aspect: 'hidden'
    },
    {
      id: 10,
      name: 'The Outcome',
      description: 'The final result',
      meaning: 'This final card reveals the ultimate outcome, resolution, or culmination of your situation based on current trajectories.',
      element: 'Spirit',
      timing: 'Final Outcome',
      aspect: 'outcome'
    }
  ]
};

// All spreads collection
export const allSpreads: SpreadConfig[] = [
  threeCardSpread,
  fiveCardSpread,
  sevenCardSpread,
  celticCrossSpread
];

// Get spread by ID
export const getSpreadById = (id: SpreadType): SpreadConfig | undefined => {
  return allSpreads.find(spread => spread.id === id);
};

// Get spread by card count
export const getSpreadByCardCount = (count: number): SpreadConfig | undefined => {
  return allSpreads.find(spread => spread.cardCount === count);
};

// Get position meaning
export const getPositionMeaning = (spreadId: SpreadType, positionId: number): string => {
  const spread = getSpreadById(spreadId);
  const position = spread?.positions.find(p => p.id === positionId);
  return position?.meaning || '';
};

// Get aspect color for UI
export const getAspectColor = (aspect: SpreadPosition['aspect']): string => {
  const colors: Record<string, string> = {
    'past': '#8B5CF6',      // Purple
    'present': '#3B82F6',   // Blue
    'future': '#F59E0B',    // Amber
    'challenge': '#EF4444', // Red
    'advice': '#10B981',    // Green
    'outcome': '#8B5CF6',   // Purple
    'self': '#EC4899',      // Pink
    'external': '#06B6D4',  // Cyan
    'hidden': '#6366F1',    // Indigo
    'spiritual': '#F97316'  // Orange
  };
  return colors[aspect] || '#6B7280';
};

// Get aspect icon
export const getAspectIcon = (aspect: SpreadPosition['aspect']): string => {
  const icons: Record<string, string> = {
    'past': 'History',
    'present': 'Eye',
    'future': 'Sparkles',
    'challenge': 'ShieldAlert',
    'advice': 'Lightbulb',
    'outcome': 'Flag',
    'self': 'User',
    'external': 'Users',
    'hidden': 'EyeOff',
    'spiritual': 'Star'
  };
  return icons[aspect] || 'Circle';
};

// Export default
export default allSpreads;

import React, { useState } from 'react';
import { ReadingProvider, useReading } from '@/store/readingStore';
import type { DeckType } from '@/data/decks';
import type { SpreadType } from '@/data/spreads';
import { createSimulator } from '@/lib/randomization';
import type { DrawnCard } from '@/store/readingStore';

// Sections
import HeroSection from '@/sections/HeroSection';
import SetupSection from '@/sections/SetupSection';
import ReadingSection from '@/sections/ReadingSection';

// Components
import ShufflingAnimation from '@/components/ShufflingAnimation';
import LLMExport from '@/components/LLMExport';
import { getSpreadById } from '@/data/spreads';

// Main App Content
const AppContent: React.FC = () => {
  const { state, dispatch } = useReading();
  const [showExport, setShowExport] = useState(false);
  const [simulator] = useState(() => createSimulator());
  
  // Scroll to section helper
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  // Start reading - scroll to setup
  const handleStartReading = () => {
    scrollToSection('setup-section');
  };
  
  // Configuration handlers
  const handleDeckChange = (deck: DeckType) => {
    dispatch({ type: 'SET_DECK', payload: deck });
  };
  
  const handleSpreadChange = (spread: SpreadType) => {
    dispatch({ type: 'SET_SPREAD', payload: spread });
  };
  
  const handleQuestionChange = (question: string) => {
    dispatch({ type: 'SET_QUESTION', payload: question });
  };
  
  // Start shuffling
  const handleStartShuffle = () => {
    dispatch({ type: 'START_SHUFFLING' });
  };
  
  // Complete shuffling and draw cards
  const handleShuffleComplete = () => {
    dispatch({ type: 'FINISH_SHUFFLING' });
    
    // Get card count based on spread
    const cardCount = state.selectedSpread === 'three' ? 3 :
                      state.selectedSpread === 'five' ? 5 :
                      state.selectedSpread === 'seven' ? 7 : 10;
    
    // Draw cards using Monte Carlo randomization
    const drawnCards = simulator.simulate(cardCount);
    const reversedStates = simulator.getReversedStates(cardCount);
    
    // Get spread positions
    const spreadConfig = getSpreadById(state.selectedSpread);
    
    // Create drawn card objects
    const cards: DrawnCard[] = drawnCards.map((card, index) => ({
      card,
      reversed: state.allowReversed ? reversedStates[index] : false,
      position: index + 1,
      positionName: spreadConfig?.positions[index]?.name || `Position ${index + 1}`
    }));
    
    // Start drawing phase
    dispatch({ type: 'START_DRAWING' });
    
    // Add cards one by one with delay
    cards.forEach((card, index) => {
      setTimeout(() => {
        dispatch({ type: 'ADD_DRAWN_CARD', payload: card });
      }, index * 200);
    });
    
    // Auto-reveal first card
    setTimeout(() => {
      dispatch({ type: 'REVEAL_NEXT_CARD' });
    }, cards.length * 200 + 500);
  };
  
  // Reveal handlers
  const handleRevealNext = () => {
    dispatch({ type: 'REVEAL_NEXT_CARD' });
    
    // Check if all cards revealed
    const cardCount = state.drawnCards.length;
    if (state.currentRevealIndex >= cardCount - 2) {
      setTimeout(() => {
        dispatch({ type: 'COMPLETE_READING' });
      }, 500);
    }
  };
  
  const handleRevealAll = () => {
    dispatch({ type: 'REVEAL_ALL_CARDS' });
    setTimeout(() => {
      dispatch({ type: 'COMPLETE_READING' });
    }, 500);
  };
  
  // Reset reading
  const handleReset = () => {
    dispatch({ type: 'RESET_READING' });
    simulator.reset();
    setShowExport(false);
    scrollToSection('setup-section');
  };
  
  // Export handler
  const handleExport = () => {
    setShowExport(true);
    scrollToSection('export-section');
  };
  
  // Render based on phase
  return (
    <div className="min-h-screen bg-gradient-mystic">
      {/* Shuffling overlay */}
      {state.phase === 'shuffling' && (
        <ShufflingAnimation 
          onComplete={handleShuffleComplete}
          duration={60000}
        />
      )}
      
      {/* Hero Section */}
      <HeroSection onStartReading={handleStartReading} />
      
      {/* Setup Section */}
      <div id="setup-section">
        <SetupSection
          selectedDeck={state.selectedDeck}
          selectedSpread={state.selectedSpread}
          question={state.question}
          onDeckChange={handleDeckChange}
          onSpreadChange={handleSpreadChange}
          onQuestionChange={handleQuestionChange}
          onStartShuffle={handleStartShuffle}
        />
      </div>
      
      {/* Reading Section */}
      {(state.phase === 'drawing' || state.phase === 'revealing' || state.phase === 'complete') && (
        <div id="reading-section">
          <ReadingSection
            cards={state.drawnCards}
            spread={state.selectedSpread}
            deck={state.selectedDeck}
            question={state.question}
            currentRevealIndex={state.currentRevealIndex}
            onRevealNext={handleRevealNext}
            onRevealAll={handleRevealAll}
            onReset={handleReset}
            onExport={handleExport}
          />
        </div>
      )}
      
      {/* Export Section */}
      {showExport && state.currentSession && (
        <div id="export-section" className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-heading text-gradient-gold text-center mb-12">
              Export Your Reading
            </h2>
            <LLMExport
              cards={state.drawnCards}
              spread={state.selectedSpread}
              deck={state.selectedDeck}
              question={state.question}
              timestamp={state.currentSession.timestamp}
            />
            
            {/* Back to reading button */}
            <div className="text-center mt-8">
              <button
                onClick={() => {
                  setShowExport(false);
                  scrollToSection('reading-section');
                }}
                className="mystic-button-secondary"
              >
                Back to Reading
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Footer */}
      <footer className="py-12 px-4 border-t border-amber-500/10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="text-2xl">✦</span>
            <span className="text-xl font-heading text-amber-400">Mystic Tarot Oracle</span>
            <span className="text-2xl">✦</span>
          </div>
          
          <p className="text-sm text-amber-200/40 mb-4">
            Authentic tarot readings with Monte Carlo randomization
          </p>
          
          <div className="flex items-center justify-center gap-6 text-xs text-amber-200/30">
            <span>78 Cards</span>
            <span>•</span>
            <span>4 Spreads</span>
            <span>•</span>
            <span>5 Decks</span>
            <span>•</span>
            <span>True Randomness</span>
          </div>
          
          <p className="text-xs text-amber-200/20 mt-8">
            For entertainment and spiritual guidance purposes only.
          </p>
        </div>
      </footer>
    </div>
  );
};

// App with Provider
function App() {
  return (
    <ReadingProvider>
      <AppContent />
    </ReadingProvider>
  );
}

export default App;

import React, { useState, useEffect } from 'react';
import type { TarotCard as TarotCardType } from '@/data/tarotCards';
import type { DeckType } from '@/data/decks';
import { getDeckById } from '@/data/decks';
import { Sparkles, RotateCcw } from 'lucide-react';

interface TarotCardProps {
  card: TarotCardType;
  reversed?: boolean;
  deck?: DeckType;
  showFace?: boolean;
  onClick?: () => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  animate?: boolean;
  delay?: number;
}

const sizeClasses = {
  sm: 'w-20 h-32',
  md: 'w-32 h-48',
  lg: 'w-44 h-64',
  xl: 'w-56 h-80'
};

export const TarotCard: React.FC<TarotCardProps> = ({
  card,
  reversed = false,
  deck = 'rider-waite',
  showFace = true,
  onClick,
  className = '',
  size = 'md',
  animate = false,
  delay = 0
}) => {
  const [isFlipped, setIsFlipped] = useState(!showFace);
  const [isVisible, setIsVisible] = useState(false);
  const deckConfig = getDeckById(deck);

  useEffect(() => {
    if (animate) {
      const timer = setTimeout(() => setIsVisible(true), delay);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(true);
    }
  }, [animate, delay]);

  const handleClick = () => {
    if (onClick) {
      setIsFlipped(!isFlipped);
      onClick();
    }
  };

  const cardStyle = {
    transform: reversed ? 'rotate(180deg)' : 'rotate(0deg)',
  };

  const getElementColor = (element: string) => {
    const colors: Record<string, string> = {
      fire: 'from-orange-500 to-red-600',
      water: 'from-blue-500 to-cyan-600',
      air: 'from-yellow-400 to-amber-500',
      earth: 'from-emerald-500 to-green-600',
      spirit: 'from-purple-500 to-violet-600'
    };
    return colors[element] || 'from-slate-500 to-gray-600';
  };

  const getSuitIcon = (suit?: string) => {
    switch (suit) {
      case 'wands': return '🔥';
      case 'cups': return '💧';
      case 'swords': return '⚔️';
      case 'pentacles': return '⬟';
      default: return '✦';
    }
  };

  return (
    <div
      className={`
        relative ${sizeClasses[size]} cursor-pointer perspective-1000
        transition-all duration-500 ease-out
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}
        ${className}
      `}
      onClick={handleClick}
      style={{ perspective: '1000px' }}
    >
      <div
        className={`
          relative w-full h-full rounded-xl transition-transform duration-700
          ${isFlipped ? '[transform:rotateY(180deg)]' : ''}
        `}
        style={{ 
          transformStyle: 'preserve-3d',
          ...cardStyle
        }}
      >
        {/* Card Front */}
        <div
          className="absolute inset-0 rounded-xl overflow-hidden backface-hidden"
          style={{ backfaceVisibility: 'hidden' }}
        >
          <div className={`
            w-full h-full bg-gradient-to-br ${getElementColor(card.element)}
            border-2 border-amber-500/50
            shadow-lg shadow-amber-500/20
            flex flex-col
          `}>
            {/* Card Header */}
            <div className="flex items-center justify-between px-2 py-1 bg-black/30">
              <span className="text-xs font-heading text-amber-100">
                {card.rank || card.name.split(' ')[0]}
              </span>
              <span className="text-xs">{getSuitIcon(card.suit)}</span>
            </div>
            
            {/* Card Image Area */}
            <div className="flex-1 relative overflow-hidden m-2 rounded-lg bg-black/20">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-2">
                  <Sparkles className="w-8 h-8 mx-auto mb-2 text-amber-300/60" />
                  <p className="text-xs text-amber-100/80 font-mystic italic">
                    {card.keywords.slice(0, 3).join(', ')}
                  </p>
                </div>
              </div>
              
              {/* Decorative corners */}
              <div className="absolute top-1 left-1 w-3 h-3 border-t border-l border-amber-400/50" />
              <div className="absolute top-1 right-1 w-3 h-3 border-t border-r border-amber-400/50" />
              <div className="absolute bottom-1 left-1 w-3 h-3 border-b border-l border-amber-400/50" />
              <div className="absolute bottom-1 right-1 w-3 h-3 border-b border-r border-amber-400/50" />
            </div>
            
            {/* Card Name */}
            <div className="px-2 py-1 bg-black/30 text-center">
              <p className="text-xs font-heading text-amber-100 truncate">
                {card.name}
              </p>
            </div>
            
            {/* Reversed indicator */}
            {reversed && (
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
                bg-red-900/80 text-red-100 px-2 py-1 rounded text-xs font-heading
                flex items-center gap-1">
                <RotateCcw className="w-3 h-3" />
                REVERSED
              </div>
            )}
          </div>
        </div>
        
        {/* Card Back */}
        <div
          className="absolute inset-0 rounded-xl overflow-hidden backface-hidden"
          style={{ 
            backfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)'
          }}
        >
          <div 
            className="w-full h-full"
            style={{
              background: `linear-gradient(135deg, ${deckConfig?.colorScheme.primary}, ${deckConfig?.colorScheme.secondary})`,
              border: `2px solid ${deckConfig?.colorScheme.accent}`,
            }}
          >
            {/* Pattern overlay */}
            <div className="absolute inset-0 opacity-30"
              style={{
                backgroundImage: `repeating-linear-gradient(
                  45deg,
                  transparent,
                  transparent 10px,
                  ${deckConfig?.colorScheme.accent}20 10px,
                  ${deckConfig?.colorScheme.accent}20 20px
                )`
              }}
            />
            
            {/* Center symbol */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div 
                className="w-16 h-16 rounded-full flex items-center justify-center"
                style={{
                  background: `linear-gradient(145deg, ${deckConfig?.colorScheme.accent}40, transparent)`,
                  border: `1px solid ${deckConfig?.colorScheme.accent}60`
                }}
              >
                <span className="text-3xl">✦</span>
              </div>
            </div>
            
            {/* Corner decorations */}
            <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-amber-500/50" />
            <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-amber-500/50" />
            <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-amber-500/50" />
            <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-amber-500/50" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TarotCard;

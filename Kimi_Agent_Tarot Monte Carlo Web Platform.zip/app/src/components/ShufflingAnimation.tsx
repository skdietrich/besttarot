import React, { useEffect, useState, useRef } from 'react';
import { Sparkles, Shuffle, Timer } from 'lucide-react';

interface ShufflingAnimationProps {
  onComplete: () => void;
  duration?: number; // in milliseconds, default 60000 (1 minute)
}

interface FloatingCard {
  id: number;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  opacity: number;
  speed: number;
  direction: number;
}

export const ShufflingAnimation: React.FC<ShufflingAnimationProps> = ({
  onComplete,
  duration = 60000
}) => {
  const [progress, setProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(duration);
  const [floatingCards, setFloatingCards] = useState<FloatingCard[]>([]);
  const [entropyValue, setEntropyValue] = useState(0);
  const animationRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(Date.now());

  // Initialize floating cards
  useEffect(() => {
    const cards: FloatingCard[] = Array.from({ length: 12 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      rotation: Math.random() * 360,
      scale: 0.5 + Math.random() * 0.5,
      opacity: 0.3 + Math.random() * 0.4,
      speed: 0.5 + Math.random() * 1,
      direction: Math.random() * Math.PI * 2
    }));
    setFloatingCards(cards);
  }, []);

  // Animation loop
  useEffect(() => {
    const animate = () => {
      const elapsed = Date.now() - startTimeRef.current;
      const newProgress = Math.min((elapsed / duration) * 100, 100);
      const newTimeRemaining = Math.max(duration - elapsed, 0);
      
      setProgress(newProgress);
      setTimeRemaining(newTimeRemaining);
      setEntropyValue(Math.random());
      
      // Update floating cards
      setFloatingCards(prev => prev.map(card => ({
        ...card,
        x: (card.x + Math.cos(card.direction) * card.speed + 100) % 100,
        y: (card.y + Math.sin(card.direction) * card.speed + 100) % 100,
        rotation: (card.rotation + card.speed * 2) % 360,
        direction: card.direction + (Math.random() - 0.5) * 0.1
      })));
      
      if (newProgress < 100) {
        animationRef.current = requestAnimationFrame(animate);
      } else {
        onComplete();
      }
    };
    
    animationRef.current = requestAnimationFrame(animate);
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [duration, onComplete]);

  const formatTime = (ms: number) => {
    const seconds = Math.ceil(ms / 1000);
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getStageMessage = () => {
    if (progress < 20) return "Gathering cosmic energies...";
    if (progress < 40) return "Aligning with universal forces...";
    if (progress < 60) return "Shuffling the ethereal deck...";
    if (progress < 80) return "Weaving probability threads...";
    return "Cards are almost ready...";
  };

  const getStageColor = () => {
    if (progress < 20) return "from-purple-500 to-blue-500";
    if (progress < 40) return "from-blue-500 to-cyan-500";
    if (progress < 60) return "from-cyan-500 to-emerald-500";
    if (progress < 80) return "from-emerald-500 to-amber-500";
    return "from-amber-500 to-orange-500";
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Floating cards */}
        {floatingCards.map(card => (
          <div
            key={card.id}
            className="absolute w-16 h-24 rounded-lg border border-amber-500/30
              bg-gradient-to-br from-purple-900/40 to-indigo-900/40
              transition-all duration-100"
            style={{
              left: `${card.x}%`,
              top: `${card.y}%`,
              transform: `rotate(${card.rotation}deg) scale(${card.scale})`,
              opacity: card.opacity
            }}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-amber-400/50" />
            </div>
          </div>
        ))}
        
        {/* Particle effects */}
        <div className="absolute inset-0">
          {Array.from({ length: 30 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 rounded-full bg-amber-400/60 twinkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`
              }}
            />
          ))}
        </div>
        
        {/* Gradient orbs */}
        <div 
          className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, hsl(45 80% 55%), transparent)',
            filter: 'blur(60px)',
            animation: 'float 6s ease-in-out infinite'
          }}
        />
        <div 
          className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, hsl(270 60% 50%), transparent)',
            filter: 'blur(50px)',
            animation: 'float 8s ease-in-out infinite reverse'
          }}
        />
      </div>
      
      {/* Main content */}
      <div className="relative z-10 text-center px-8">
        {/* Icon */}
        <div className="mb-8 relative">
          <div className={`
            w-24 h-24 mx-auto rounded-full flex items-center justify-center
            bg-gradient-to-br ${getStageColor()}
            shadow-lg animate-pulse
          `}>
            <Shuffle className="w-12 h-12 text-white" />
          </div>
          
          {/* Orbiting particles */}
          <div className="absolute inset-0 animate-spin" style={{ animationDuration: '3s' }}>
            <div className="absolute -top-2 left-1/2 w-3 h-3 rounded-full bg-amber-400" />
          </div>
          <div className="absolute inset-0 animate-spin" style={{ animationDuration: '4s', animationDirection: 'reverse' }}>
            <div className="absolute -bottom-2 left-1/2 w-2 h-2 rounded-full bg-purple-400" />
          </div>
        </div>
        
        {/* Title */}
        <h2 className="text-3xl md:text-4xl font-heading text-gradient-gold mb-4">
          The Cards Are Shuffling
        </h2>
        
        {/* Stage message */}
        <p className="text-lg text-amber-200/80 font-mystic mb-8">
          {getStageMessage()}
        </p>
        
        {/* Progress bar */}
        <div className="max-w-md mx-auto mb-6">
          <div className="mystic-progress h-3">
            <div 
              className={`
                h-full rounded-full transition-all duration-300
                bg-gradient-to-r ${getStageColor()}
              `}
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between mt-2 text-sm text-amber-400/60">
            <span>{Math.round(progress)}%</span>
            <span className="flex items-center gap-1">
              <Timer className="w-4 h-4" />
              {formatTime(timeRemaining)}
            </span>
          </div>
        </div>
        
        {/* Entropy indicator */}
        <div className="flex items-center justify-center gap-4 text-sm text-amber-300/50">
          <span>Monte Carlo Iterations:</span>
          <span className="font-mono text-amber-400">
            {Math.floor(progress * 100).toLocaleString()}
          </span>
        </div>
        
        {/* Randomization stats */}
        <div className="mt-6 flex items-center justify-center gap-8 text-xs text-amber-200/40">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span>Anti-Bias Active</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span>Entropy Pool: {Math.floor(entropyValue * 256)}</span>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="mt-12 flex items-center justify-center gap-4">
          <div className="w-16 h-px bg-gradient-to-r from-transparent to-amber-500/50" />
          <Sparkles className="w-5 h-5 text-amber-400/60" />
          <div className="w-16 h-px bg-gradient-to-l from-transparent to-amber-500/50" />
        </div>
      </div>
    </div>
  );
};

export default ShufflingAnimation;

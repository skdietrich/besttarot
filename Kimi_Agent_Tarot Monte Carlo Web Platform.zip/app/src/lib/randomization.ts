// Sophisticated Monte Carlo Randomization System with Anti-Bias Algorithms
// For truly unique and unbiased tarot card draws

import { fullDeck } from '@/data/tarotCards';
import type { TarotCard } from '@/data/tarotCards';

// Configuration for randomization
interface RandomizationConfig {
  // Number of Monte Carlo iterations
  iterations: number;
  // Entropy pool size
  entropyPoolSize: number;
  // Anti-bias strength (0-1)
  antiBiasStrength: number;
  // Enable quantum-inspired randomness
  useQuantumRandomness: boolean;
  // Session seed for reproducibility
  sessionSeed: string;
}

// Default configuration
const defaultConfig: RandomizationConfig = {
  iterations: 10000,
  entropyPoolSize: 256,
  antiBiasStrength: 0.95,
  useQuantumRandomness: true,
  sessionSeed: generateSessionSeed()
};

// Generate a unique session seed
function generateSessionSeed(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 15);
  const entropy = generateEntropyString(16);
  return `${timestamp}-${random}-${entropy}`;
}

// Generate entropy string from multiple sources
function generateEntropyString(length: number): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  
  // Combine multiple entropy sources
  const sources = [
    () => Math.random(),
    () => (Date.now() % 1000) / 1000,
    () => performance.now() % 1,
    () => Math.sin(Date.now()) * 0.5 + 0.5,
    () => Math.cos(performance.now()) * 0.5 + 0.5
  ];
  
  for (let i = 0; i < length; i++) {
    let value = 0;
    sources.forEach((source, idx) => {
      value += source() * Math.pow(0.5, idx);
    });
    result += chars[Math.floor((value % 1) * chars.length)];
  }
  
  return result;
}

// Seeded random number generator (Mulberry32)
class SeededRandom {
  private state: number;
  
  constructor(seed: string) {
    // Create numeric seed from string
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      const char = seed.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    this.state = Math.abs(hash) || 1;
  }
  
  // Generate next random number (0-1)
  next(): number {
    this.state = (this.state + 0x6D2B79F5) | 0;
    let t = this.state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  
  // Box-Muller transform for normal distribution
  nextNormal(mean: number = 0, stdDev: number = 1): number {
    const u1 = this.next();
    const u2 = this.next();
    const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return z0 * stdDev + mean;
  }
  
  // Generate random integer in range
  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }
}

// Entropy pool for enhanced randomness
class EntropyPool {
  private pool: number[];
  private index: number;
  
  constructor(size: number) {
    this.pool = new Array(size).fill(0).map(() => Math.random());
    this.index = 0;
  }
  
  // Mix entropy into the pool
  mix(value: number): void {
    this.pool[this.index] = (this.pool[this.index] + value) % 1;
    this.index = (this.index + 1) % this.pool.length;
  }
  
  // Get mixed entropy value
  getMixed(): number {
    // Combine multiple pool values
    let mixed = 0;
    const indices = [
      this.index,
      (this.index + 1) % this.pool.length,
      (this.index + Math.floor(this.pool.length / 2)) % this.pool.length
    ];
    
    indices.forEach((idx, i) => {
      mixed += this.pool[idx] * Math.pow(0.5, i);
    });
    
    return mixed % 1;
  }
  
  // Stir the pool with new entropy
  stir(): void {
    const newEntropy = generateEntropyValues(this.pool.length);
    this.pool = this.pool.map((val, i) => (val + newEntropy[i]) % 1);
  }
}

// Generate array of entropy values
function generateEntropyValues(count: number): number[] {
  return Array.from({ length: count }, () => {
    // Combine multiple entropy sources
    const sources = [
      Math.random(),
      (Date.now() % 1000000) / 1000000,
      performance.now() % 1,
      Math.sin(Date.now() * Math.random()) * 0.5 + 0.5
    ];
    return sources.reduce((a, b) => (a + b) % 1, 0) / sources.length;
  });
}

// Anti-bias detection and correction
class AntiBiasSystem {
  private history: Map<number, number> = new Map();
  private readonly maxHistory: number = 1000;
  private readonly biasThreshold: number = 0.15;
  
  // Record a card draw
  recordDraw(cardId: number): void {
    const count = this.history.get(cardId) || 0;
    this.history.set(cardId, count + 1);
    
    // Trim history if too large
    if (this.history.size > this.maxHistory) {
      const firstKey = this.history.keys().next().value;
      if (firstKey !== undefined) {
        this.history.delete(firstKey);
      }
    }
  }
  
  // Calculate bias score for a card (0 = no bias, 1 = high bias)
  calculateBias(cardId: number, totalDraws: number): number {
    if (totalDraws === 0) return 0;
    
    const cardCount = this.history.get(cardId) || 0;
    const expectedFrequency = 1 / 78; // 78 cards in deck
    const actualFrequency = cardCount / totalDraws;
    
    // Calculate deviation from expected
    const deviation = Math.abs(actualFrequency - expectedFrequency);
    return Math.min(deviation / expectedFrequency, 1);
  }
  
  // Get bias-corrected probability
  getCorrectedProbability(cardId: number, baseProb: number, totalDraws: number, strength: number): number {
    const bias = this.calculateBias(cardId, totalDraws);
    
    if (bias > this.biasThreshold) {
      // Reduce probability for over-represented cards
      const correction = 1 - (bias * strength);
      return baseProb * correction;
    }
    
    return baseProb;
  }
  
  // Check if distribution is biased
  isDistributionBiased(): boolean {
    const total = Array.from(this.history.values()).reduce((a, b) => a + b, 0);
    if (total < 78) return false;
    
    const expected = total / 78;
    let chiSquare = 0;
    
    for (let i = 0; i < 78; i++) {
      const observed = this.history.get(i) || 0;
      chiSquare += Math.pow(observed - expected, 2) / expected;
    }
    
    // Chi-square critical value for 77 df at 0.05 significance
    return chiSquare > 100;
  }
  
  // Clear history
  clear(): void {
    this.history.clear();
  }
  
  // Get history for stats
  getHistory(): Map<number, number> {
    return this.history;
  }
}

// Monte Carlo simulation for card selection
class MonteCarloSimulator {
  private rng: SeededRandom;
  private entropyPool: EntropyPool;
  private antiBias: AntiBiasSystem;
  private config: RandomizationConfig;
  private totalDraws: number = 0;
  
  constructor(config: Partial<RandomizationConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
    this.rng = new SeededRandom(this.config.sessionSeed);
    this.entropyPool = new EntropyPool(this.config.entropyPoolSize);
    this.antiBias = new AntiBiasSystem();
  }
  
  // Run Monte Carlo simulation to select cards
  simulate(cardCount: number, excludeCards: number[] = []): TarotCard[] {
    const availableCards = fullDeck.filter(c => !excludeCards.includes(c.id));
    const selected: TarotCard[] = [];
    const selectedIds = new Set<number>();
    
    // Run multiple iterations for each card selection
    for (let i = 0; i < cardCount; i++) {
      // Stir entropy pool before each selection
      this.entropyPool.stir();
      
      // Run Monte Carlo iterations
      const cardScores = this.runIterations(availableCards, selectedIds);
      
      // Select card based on weighted probabilities
      const selectedCard = this.weightedSelect(availableCards, cardScores);
      
      if (selectedCard) {
        selected.push(selectedCard);
        selectedIds.add(selectedCard.id);
        this.antiBias.recordDraw(selectedCard.id);
        this.totalDraws++;
      }
    }
    
    return selected;
  }
  
  // Run Monte Carlo iterations
  private runIterations(availableCards: TarotCard[], excludeIds: Set<number>): Map<number, number> {
    const scores = new Map<number, number>();
    
    // Initialize scores
    availableCards.forEach(card => {
      if (!excludeIds.has(card.id)) {
        scores.set(card.id, 0);
      }
    });
    
    // Run iterations
    for (let i = 0; i < this.config.iterations; i++) {
      // Generate random value with multiple entropy sources
      const entropyValue = this.generateEntropyValue(i);
      
      // Map to card index
      const cardIndex = Math.floor(entropyValue * availableCards.length);
      const card = availableCards[cardIndex];
      
      if (card && !excludeIds.has(card.id)) {
        // Update score with decay to prevent dominance
        const currentScore = scores.get(card.id) || 0;
        const decayFactor = 1 - (i / this.config.iterations);
        scores.set(card.id, currentScore + decayFactor);
      }
    }
    
    return scores;
  }
  
  // Generate entropy value from multiple sources
  private generateEntropyValue(iteration: number): number {
    const sources = [
      this.rng.next(),
      this.entropyPool.getMixed(),
      Math.random(),
      (Math.sin(iteration * 0.1) + 1) / 2,
      (Date.now() % 10000) / 10000
    ];
    
    // Weighted combination
    const weights = [0.3, 0.3, 0.2, 0.1, 0.1];
    let combined = 0;
    
    sources.forEach((source, i) => {
      combined += source * weights[i];
    });
    
    return combined % 1;
  }
  
  // Weighted random selection
  private weightedSelect(cards: TarotCard[], scores: Map<number, number>): TarotCard | null {
    const availableCards = cards.filter(c => scores.has(c.id));
    if (availableCards.length === 0) return null;
    
    // Calculate total weight with anti-bias correction
    let totalWeight = 0;
    const weights = new Map<number, number>();
    
    availableCards.forEach(card => {
      const baseScore = scores.get(card.id) || 1;
      const baseProb = baseScore / Array.from(scores.values()).reduce((a, b) => a + b, 0);
      
      // Apply anti-bias correction
      const correctedProb = this.antiBias.getCorrectedProbability(
        card.id,
        baseProb,
        this.totalDraws,
        this.config.antiBiasStrength
      );
      
      weights.set(card.id, correctedProb);
      totalWeight += correctedProb;
    });
    
    // Select based on cumulative weights
    let random = this.rng.next() * totalWeight;
    
    for (const card of availableCards) {
      const weight = weights.get(card.id) || 0;
      random -= weight;
      if (random <= 0) {
        return card;
      }
    }
    
    // Fallback to last card
    return availableCards[availableCards.length - 1];
  }
  
  // Get random boolean (for reversed cards)
  getReversed(): boolean {
    // Use normal distribution for more natural feeling
    const normal = this.rng.nextNormal(0, 1);
    return normal > 0.3; // Slightly more upright than reversed
  }
  
  // Get multiple reversed states
  getReversedStates(count: number): boolean[] {
    return Array.from({ length: count }, () => this.getReversed());
  }
  
  // Check if distribution is biased
  isBiased(): boolean {
    return this.antiBias.isDistributionBiased();
  }
  
  // Get statistics
  getStats(): {
    totalDraws: number;
    isBiased: boolean;
    uniqueCards: number;
    mostDrawnCard: { id: number; count: number } | null;
  } {
    const history = this.antiBias.getHistory();
    const entries = Array.from(history.entries());
    
    let mostDrawn: { id: number; count: number } | null = null;
    let maxCount = 0;
    
    entries.forEach(([id, count]) => {
      if (count > maxCount) {
        maxCount = count;
        mostDrawn = { id, count };
      }
    });
    
    return {
      totalDraws: this.totalDraws,
      isBiased: this.isBiased(),
      uniqueCards: history.size,
      mostDrawnCard: mostDrawn
    };
  }
  
  // Reset the simulator
  reset(): void {
    this.antiBias.clear();
    this.totalDraws = 0;
    this.rng = new SeededRandom(generateSessionSeed());
    this.entropyPool = new EntropyPool(this.config.entropyPoolSize);
  }
}

// Main randomization function
export function drawCards(
  cardCount: number,
  config?: Partial<RandomizationConfig>
): { card: TarotCard; reversed: boolean }[] {
  const simulator = new MonteCarloSimulator(config);
  const cards = simulator.simulate(cardCount);
  const reversedStates = simulator.getReversedStates(cardCount);
  
  return cards.map((card, i) => ({
    card,
    reversed: reversedStates[i]
  }));
}

// Create a new simulator instance
export function createSimulator(config?: Partial<RandomizationConfig>): MonteCarloSimulator {
  return new MonteCarloSimulator(config);
}

// Generate unique session ID
export function generateSessionId(): string {
  return generateSessionSeed();
}

// Verify randomness quality (statistical test)
export function verifyRandomness(draws: number[]): {
  chiSquare: number;
  isRandom: boolean;
  entropy: number;
} {
  const bins = new Array(78).fill(0);
  draws.forEach(id => bins[id]++);
  
  const expected = draws.length / 78;
  let chiSquare = 0;
  
  bins.forEach(observed => {
    chiSquare += Math.pow(observed - expected, 2) / expected;
  });
  
  // Calculate entropy
  let entropy = 0;
  bins.forEach(count => {
    if (count > 0) {
      const p = count / draws.length;
      entropy -= p * Math.log2(p);
    }
  });
  
  // Maximum entropy for 78 cards
  const maxEntropy = Math.log2(78);
  
  return {
    chiSquare,
    isRandom: chiSquare < 100, // Critical value approximation
    entropy: entropy / maxEntropy // Normalized entropy (1 = perfect)
  };
}

// Export types and classes
export type { RandomizationConfig };
export { SeededRandom, EntropyPool, AntiBiasSystem, MonteCarloSimulator };
